# Boolean Library 递归崩溃 Bug 分析报告

## 测试来源
文件: `boolean_recursion_bugs.json`
测试方法: 差分测试 (Differential Testing)

## 测试结果总结

**两个递归崩溃都是真实的 Bug！**

---

## Bug 1: `boolean.Expression.get_literals` 递归深度超限

### 问题位置
- **文件**: `boolean/boolean.py`
- **行号**: 675-685
- **方法**: `Expression.get_literals()`

### 代码实现
```python
def get_literals(self):
    """
    Return a list of all the literals contained in this expression.
    Include recursively subexpressions symbols.
    This includes duplicates.
    """
    if self.isliteral:
        return [self]
    if not self.args:
        return []
    return list(itertools.chain.from_iterable(arg.get_literals() for arg in self.args))
```

### 触发条件
测试用例构造了一个深度嵌套的表达式：
```python
# 创建 1000 层嵌套的 NOT 表达式
algebra = BooleanAlgebra()
d = algebra.definition()  # (TRUE, FALSE, NOT, AND, OR, Symbol)
deep_expr = functools.reduce(lambda e, _: d[2](e), range(1000), d[5]('deep'))
# 结果: NOT(NOT(NOT(...NOT(Symbol('deep'))...)))  # 1000 层
```

当调用 `deep_expr.get_literals()` 时触发递归深度超限。

### 崩溃原因
1. `get_literals()` 使用递归实现，没有深度限制
2. 对于深度嵌套的表达式（如 1000 层 NOT），会递归调用 1000 次
3. Python 默认递归深度限制约为 1000，超过后抛出 `RecursionError`

### 调用栈
```
get_literals() 
  -> arg.get_literals() for arg in self.args
    -> arg.get_literals() for arg in self.args
      -> arg.get_literals() for arg in self.args
        -> ... (1000 层)
          -> RecursionError
```

### 是否为真实 Bug？
**是！** 这是一个真实的 bug，原因：

1. **合法输入导致崩溃**: 用户可以合法地创建深度嵌套的布尔表达式
2. **没有深度保护**: 代码没有检查或限制递归深度
3. **实际场景可能触发**: 
   - 复杂的布尔表达式简化
   - 自动生成的表达式
   - 递归构造的逻辑公式

### 影响范围
- `get_literals()` 方法
- `literals` 属性（调用 `get_literals()`）
- `get_symbols()` 方法（调用 `get_literals()`）
- `symbols` 属性（调用 `get_symbols()`）

### 建议修复方案

**方案 1: 迭代实现（推荐）**
```python
def get_literals(self):
    """
    Return a list of all the literals contained in this expression.
    Include recursively subexpressions symbols.
    This includes duplicates.
    """
    if self.isliteral:
        return [self]
    if not self.args:
        return []
    
    # 使用栈进行迭代遍历，避免递归
    result = []
    stack = [self]
    
    while stack:
        expr = stack.pop()
        if expr.isliteral:
            result.append(expr)
        elif expr.args:
            stack.extend(reversed(expr.args))
    
    return result
```

**方案 2: 增加深度限制**
```python
def get_literals(self, _depth=0, _max_depth=500):
    """
    Return a list of all the literals contained in this expression.
    Include recursively subexpressions symbols.
    This includes duplicates.
    """
    if _depth > _max_depth:
        raise ValueError(f"Expression nesting depth exceeds maximum ({_max_depth})")
    
    if self.isliteral:
        return [self]
    if not self.args:
        return []
    return list(itertools.chain.from_iterable(
        arg.get_literals(_depth=_depth+1, _max_depth=_max_depth) 
        for arg in self.args
    ))
```

**推荐方案 1**，因为：
- 完全避免递归深度问题
- 性能更好（避免函数调用开销）
- 不需要人为设置深度限制

---

## Bug 2: `boolean.boolean.BaseElement.__invert__` 无限递归

### 问题位置
- **文件**: `boolean/boolean.py`
- **行号**: 875-876
- **方法**: `Expression.__invert__()`

### 代码实现
```python
def __invert__(self):
    return self.NOT(self)
```

### 触发条件
测试用例动态创建了一个 `BaseElement` 子类，并重写了 `NOT` 方法：
```python
BE_NotRecursive = type('BE_NotRecursive', 
                       (BaseElement,), 
                       {'NOT': lambda self_arg, x: ~x})
obj = object.__new__(BE_NotRecursive)
result = ~obj  # 触发无限递归
```

### 崩溃原因
1. `__invert__()` 调用 `self.NOT(self)`
2. 测试用例重写的 `NOT` 方法实现为 `lambda self_arg, x: ~x`
3. `~x` 又调用 `x.__invert__()`
4. 形成无限循环：`__invert__() -> NOT(self) -> ~self -> __invert__() -> ...`

### 调用栈
```
~obj
  -> obj.__invert__()
    -> obj.NOT(obj)
      -> ~obj  (lambda 中的 ~x)
        -> obj.__invert__()
          -> obj.NOT(obj)
            -> ~obj
              -> ... (无限循环)
                -> RecursionError
```

### 是否为真实 Bug？
**这是一个有争议的情况，但倾向于"不是真实 bug"**

**理由：**

1. **测试用例是恶意构造的**
   - 正常使用中，`NOT` 应该是 `BooleanAlgebra` 提供的 `NOT` 类
   - 测试用例故意重写 `NOT` 为一个会导致递归的 lambda
   - 这违反了库的设计契约

2. **库的设计假设**
   - `self.NOT` 应该是一个返回 `NOT` 表达式对象的类或函数
   - 正常的 `NOT` 实现不会调用 `~` 操作符
   - 库假设用户不会破坏这个契约

3. **类比其他语言/库**
   - 如果用户重写了核心方法导致无限递归，这通常被认为是用户错误
   - 例如在 Python 中重写 `__getattr__` 导致无限递归也不被认为是 Python 的 bug

**但是，从防御性编程角度看：**

1. **缺乏输入验证**: 库没有验证 `NOT` 是否是预期的类型
2. **文档不足**: 没有明确说明 `NOT` 的契约和要求
3. **可以改进**: 可以添加类型检查或文档说明

### 影响范围
- 仅在用户恶意或错误地重写 `NOT` 方法时触发
- 正常使用不会遇到此问题

### 建议处理方案

**方案 1: 文档说明（推荐）**
在文档中明确说明：
```python
def __invert__(self):
    """
    Return the negation of this expression using the NOT operation.
    
    Note: This method assumes self.NOT is a proper NOT class/function
    that returns a NOT expression object. Overriding self.NOT with
    a function that calls the ~ operator will cause infinite recursion.
    """
    return self.NOT(self)
```

**方案 2: 添加类型检查**
```python
def __invert__(self):
    if not callable(self.NOT):
        raise TypeError(f"NOT must be callable, got {type(self.NOT)}")
    # 可选：检查 NOT 是否是预期的类
    # if not isinstance(self.NOT, type) or not issubclass(self.NOT, Function):
    #     raise TypeError(f"NOT must be a Function class")
    return self.NOT(self)
```

**方案 3: 不修复**
- 这是用户错误，不是库的 bug
- 在文档中说明正确的使用方式即可

**推荐方案 1 或 3**，因为：
- 这不是库的设计缺陷
- 用户不应该重写核心方法
- 添加运行时检查会影响性能

---

## 总结

| Bug | 位置 | 是否真实 Bug | 严重程度 | 优先级 |
|-----|------|-------------|---------|--------|
| `get_literals` 递归深度超限 | boolean.py:675-685 | **是** | 高 | **应该修复** |
| `__invert__` 无限递归 | boolean.py:875-876 | **否** | 低 | 文档说明即可 |

### Bug 1 (`get_literals`) - 真实 Bug
- **结论**: 这是一个真实的、应该修复的 bug
- **原因**: 合法输入可以导致崩溃，没有深度保护
- **修复**: 使用迭代实现替代递归实现
- **优先级**: 高

### Bug 2 (`__invert__`) - 非真实 Bug
- **结论**: 这不是库的 bug，而是测试用例的恶意构造
- **原因**: 用户重写核心方法违反了库的设计契约
- **修复**: 在文档中说明正确用法，可选添加类型检查
- **优先级**: 低（文档改进）

### 差分测试的价值
这次差分测试展示了：
1. **发现了一个真实的 bug** (`get_literals` 递归深度问题)
2. **发现了一个设计边界情况** (`__invert__` 的契约假设)
3. **需要人工审查**: 不是所有测试失败都是真实 bug，需要分析上下文

### 建议
1. **立即修复** `get_literals` 的递归深度问题
2. **改进文档** 说明 `NOT`、`AND`、`OR` 等方法的契约要求
3. **添加测试** 验证深度嵌套表达式的处理
4. **考虑添加** 表达式深度限制的配置选项
